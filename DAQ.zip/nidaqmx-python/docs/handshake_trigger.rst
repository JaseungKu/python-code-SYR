nidaqmx.task.handshake_trigger
==============================

.. automodule:: nidaqmx._task_modules.triggering.handshake_trigger
    :members:
    :show-inheritance:
