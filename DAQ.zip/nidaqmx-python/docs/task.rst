nidaqmx.task
============
.. automodule:: nidaqmx.task
    :members:
    :show-inheritance:
    :special-members:

.. toctree::
   
   channel
   channel_collection
   export_signals
   in_stream
   out_stream
   timing
   triggers