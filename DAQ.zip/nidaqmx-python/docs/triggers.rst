nidaqmx.task.triggers
=====================

.. automodule:: nidaqmx._task_modules.triggers
    :members:
    :show-inheritance:

.. toctree::
   
   arm_start_trigger
   handshake_trigger
   pause_trigger
   reference_trigger
   start_trigger