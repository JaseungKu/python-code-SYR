nidaqmx.task.pause_trigger
==========================

.. automodule:: nidaqmx._task_modules.triggering.pause_trigger
    :members:
    :show-inheritance:
