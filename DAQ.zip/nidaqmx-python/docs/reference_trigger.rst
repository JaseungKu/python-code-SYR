nidaqmx.task.reference_trigger
==============================

.. automodule:: nidaqmx._task_modules.triggering.reference_trigger
    :members:
    :show-inheritance:
