nidaqmx.system.expiration_state
===============================

.. automodule:: nidaqmx.system._watchdog_modules.expiration_state
    :members:
    :show-inheritance:
